package com.um.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.um.model.UserVo;
import com.um.repository.UserRepository;
import com.um.utility.UserManagmentException;

@Service
public class UserService {

	public static final Logger logger = LoggerFactory.getLogger(UserService.class);

	@Autowired(required=true)
	private UserRepository userRepository;

	public List<UserVo> getAllUserDetailsUsers() {
		return userRepository.findAll();
	}
	@Cacheable(value="movielibrary", key="#id")
	public UserVo getUserById(Long id) throws Exception {
		Optional<UserVo> user= userRepository.findById(id);
		if(user.isEmpty()) {
			throw new Exception("Can not find movie with id: "+id);
		} else {
			return user.get();
		}
	}

	public UserVo insertUserData(UserVo user) {
		
		return userRepository.save(user);
	}

	@CachePut(value="userlibrary", key="#id")
	public UserVo updateUserData(UserVo user) throws Exception {
		if(user!=null&& user.getUserId()>0) {
			return userRepository.save(user);
		}
		else {
			throw new Exception("Can not find user with id: "+user.getUserId());
		}
	}
	@CacheEvict(value="userlibrary", key="#id")
	public UserVo deleteUserById(Long id) throws Exception {
		if(id>0) {
			UserVo user=getUserById(id);
			if(user!=null&&!user.getUserName().equalsIgnoreCase("")) {
				 userRepository.deleteById(id);
				 return user;
			}
		}
		 throw new UserManagmentException("Can not delete User with id: "+id);
		
	}
}
